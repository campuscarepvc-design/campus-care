import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { StatusBadge } from '../common/StatusBadge';
import { PriorityBadge } from '../common/PriorityBadge';
import { CategoryIcon } from '../common/CategoryIcon';
import {
  Send,
  Building,
  CheckCircle2,
  Clock,
  Wrench,
  AlertTriangle,
  ChevronRight,
  Sparkles,
  MapPin,
  Calendar,
  MessageSquare,
  Users,
} from 'lucide-react';

interface FacultyDashboardProps {
  setActiveTab: (tab: string) => void;
  onOpenReport: () => void;
}

export const FacultyDashboard: React.FC<FacultyDashboardProps> = ({
  setActiveTab,
  onOpenReport,
}) => {
  const { currentUser } = useAuth();
  const { complaints, openComplaintDetails } = useData();

  const myReports = complaints.filter(
    (c) => currentUser && c.submitterId === currentUser.id
  );

  const pending = myReports.filter((c) => c.status === 'Pending').length;
  const inProgress = myReports.filter(
    (c) => c.status === 'In Progress' || c.status === 'Assigned'
  ).length;
  const resolved = myReports.filter((c) => c.status === 'Resolved').length;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold mb-3 border border-indigo-400/20 backdrop-blur-xs">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Faculty Academic Facility Directorate</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Good day, {currentUser?.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 font-normal leading-relaxed">
              {currentUser?.designation} • {currentUser?.department}
              <br />
              <span className="text-sky-300 font-mono text-xs">
                {currentUser?.cabinNo} • Phone: {currentUser?.phone}
              </span>
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={onOpenReport}
              className="px-5 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Report to HOD</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('complaints')}
              className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <span>View All Reports</span>
              <ChevronRight className="w-4 h-4 text-sky-400" />
            </button>
          </div>
        </div>

        {/* Decorative background shapes */}
        <div className="absolute -right-12 -bottom-12 w-64 h-64 rounded-full bg-indigo-500/10 blur-2xl pointer-events-none" />
      </div>

      {/* 4 Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-blue-300 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Total Reports
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{myReports.length}</span>
            <span className="text-xs text-slate-500">submitted</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-amber-300 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
              Pending HOD Review
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-amber-700">{pending}</span>
            <span className="text-xs text-slate-500">awaiting triage</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-indigo-300 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              Maintenance Active
            </span>
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Wrench className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-indigo-700">{inProgress}</span>
            <span className="text-xs text-slate-500">under repair</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-emerald-300 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
              Resolved & Verified
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-emerald-700">{resolved}</span>
            <span className="text-xs text-emerald-600 font-semibold">completed</span>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Faculty Reports */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Recent Department Reports Filed to HOD
                </h3>
                <p className="text-xs text-slate-500">
                  Lab equipment, lecture halls, and infrastructure maintenance
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('complaints')}
                className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
              >
                <span>View all</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {myReports.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400">
                  No reports filed yet. Use "Report to HOD" for any academic infrastructure needs.
                </div>
              ) : (
                myReports.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => openComplaintDetails(item)}
                    className="p-4 sm:p-5 hover:bg-slate-50/80 transition cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
                  >
                    <div className="flex items-start gap-3.5">
                      <CategoryIcon
                        category={item.category}
                        showBackground
                        className="w-5 h-5"
                      />
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-mono text-xs font-bold text-blue-700">
                            {item.id}
                          </span>
                          <StatusBadge status={item.status} size="sm" />
                          <PriorityBadge priority={item.priority} size="sm" />
                          {item.estimatedAffectedStudents && (
                            <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md">
                              Affects {item.estimatedAffectedStudents} students
                            </span>
                          )}
                        </div>
                        <h4 className="text-sm font-bold text-slate-800 mt-1 group-hover:text-blue-600 transition">
                          {item.title}
                        </h4>
                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1.5">
                          <span className="flex items-center gap-1 font-medium text-slate-700">
                            <Building className="w-3.5 h-3.5 text-slate-400" />
                            {item.classroomOrLab}
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-slate-400" />
                            {item.location}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100 text-xs">
                      {item.assignedTeam ? (
                        <div className="text-left sm:text-right">
                          <span className="text-[10px] text-slate-400 block">Assigned:</span>
                          <span className="font-semibold text-slate-700 text-xs truncate max-w-[140px] block">
                            {item.assignedTeam}
                          </span>
                        </div>
                      ) : (
                        <span className="text-amber-600 text-xs font-medium">Awaiting HOD assignment</span>
                      )}
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 group-hover:text-blue-600 transition" />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right Col: HOD Direct Channel */}
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-2 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-blue-600" />
              <span>HOD Escalation Protocol</span>
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Dr. S. Radhakrishnan (HOD Operations) reviews faculty lab tickets with priority dispatch within 2 hours for ongoing coursework disruptions.
            </p>
            <button
              type="button"
              onClick={() => setActiveTab('messages')}
              className="mt-4 w-full py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <MessageSquare className="w-4 h-4 text-sky-400" />
              <span>Message HOD Office</span>
            </button>
          </div>

          <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 text-xs text-blue-900 space-y-2">
            <div className="font-bold flex items-center gap-1.5">
              <Users className="w-4 h-4 text-blue-600" />
              <span>Classroom Reallocation Support</span>
            </div>
            <p className="text-[11px] text-slate-600">
              If an AV failure or lab issue disrupts a scheduled lecture batch, request mobile AV trolley or seminar hall buffer via internal messages.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
