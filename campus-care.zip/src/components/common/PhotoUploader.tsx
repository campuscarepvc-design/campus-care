import React, { useState, useRef } from 'react';
import { Camera, Upload, X, Check, Image as ImageIcon, Sparkles } from 'lucide-react';

interface PhotoUploaderProps {
  photoUrl?: string;
  photoCaption?: string;
  onPhotoChange: (url?: string, caption?: string) => void;
}

const SAMPLE_CAMPUS_PRESETS = [
  {
    name: 'Electrical Hazard',
    url: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80',
    caption: 'Burnt wiring socket and trip switch in lecture room',
  },
  {
    name: 'Water / Plumbing',
    url: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=600&auto=format&fit=crop&q=80',
    caption: 'Water pipe leakage and standing water on corridor floor',
  },
  {
    name: 'Classroom AV',
    url: 'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=600&auto=format&fit=crop&q=80',
    caption: 'Projector unit offline with flashing error indicator',
  },
  {
    name: 'IT / Wi-Fi',
    url: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=600&auto=format&fit=crop&q=80',
    caption: 'Ceiling network access point indicator down',
  },
];

export const PhotoUploader: React.FC<PhotoUploaderProps> = ({
  photoUrl,
  photoCaption,
  onPhotoChange,
}) => {
  const [caption, setCaption] = useState(photoCaption || '');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      onPhotoChange(dataUrl, caption || file.name);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleSelectPreset = (preset: typeof SAMPLE_CAMPUS_PRESETS[0]) => {
    setCaption(preset.caption);
    onPhotoChange(preset.url, preset.caption);
  };

  const handleClear = () => {
    setCaption('');
    onPhotoChange(undefined, undefined);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <label className="block text-sm font-semibold text-slate-700">
          Photo Evidence / Attachment
          <span className="text-slate-400 font-normal ml-1.5">(Optional but recommended)</span>
        </label>
        {photoUrl && (
          <button
            type="button"
            onClick={handleClear}
            className="text-xs text-rose-600 hover:text-rose-700 font-medium inline-flex items-center gap-1 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" /> Remove photo
          </button>
        )}
      </div>

      {photoUrl ? (
        <div className="relative rounded-xl border border-slate-200 overflow-hidden bg-slate-50 p-2">
          <div className="relative h-48 w-full rounded-lg overflow-hidden bg-slate-900/5 flex items-center justify-center">
            <img
              src={photoUrl}
              alt="Problem Evidence"
              className="w-full h-full object-cover"
            />
            <div className="absolute top-2 right-2 bg-slate-900/70 text-white text-xs px-2.5 py-1 rounded-md backdrop-blur-xs flex items-center gap-1">
              <Check className="w-3.5 h-3.5 text-emerald-400" /> Attached
            </div>
          </div>
          <div className="mt-2.5">
            <input
              type="text"
              placeholder="Add photo caption or detail (e.g., crack in wall, burnt plug)"
              value={caption}
              onChange={(e) => {
                setCaption(e.target.value);
                onPhotoChange(photoUrl, e.target.value);
              }}
              className="w-full text-xs text-slate-700 bg-white border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>
        </div>
      ) : (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-all duration-200 ${
            isDragging
              ? 'border-blue-500 bg-blue-50/50'
              : 'border-slate-300 hover:border-blue-400 bg-white hover:bg-slate-50/70'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFile(e.target.files[0]);
              }
            }}
          />
          <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-3">
            <Camera className="w-6 h-6" />
          </div>
          <p className="text-sm font-semibold text-slate-700">
            Click to upload photo or drag & drop
          </p>
          <p className="text-xs text-slate-500 mt-1">
            PNG, JPG, WEBP up to 10MB
          </p>
        </div>
      )}

      {/* Quick Sample Incident Photo Presets for Demo */}
      {!photoUrl && (
        <div className="pt-1">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-2 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Or choose a demo campus incident photo:</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {SAMPLE_CAMPUS_PRESETS.map((preset) => (
              <button
                key={preset.name}
                type="button"
                onClick={() => handleSelectPreset(preset)}
                className="group p-1.5 rounded-lg border border-slate-200 bg-white hover:border-blue-300 hover:shadow-xs transition text-left cursor-pointer"
              >
                <div className="h-14 w-full rounded overflow-hidden mb-1 bg-slate-100">
                  <img
                    src={preset.url}
                    alt={preset.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                </div>
                <div className="text-[11px] font-semibold text-slate-700 truncate group-hover:text-blue-600">
                  {preset.name}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
