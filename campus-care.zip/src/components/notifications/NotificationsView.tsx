import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import {
  Bell,
  CheckCircle2,
  Building,
  Clock,
  MessageSquare,
  AlertCircle,
  CheckCheck,
} from 'lucide-react';

interface NotificationsViewProps {
  onSelectComplaint?: (id: string) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  onSelectComplaint,
}) => {
  const { currentUser } = useAuth();
  const {
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    complaints,
    openComplaintDetails,
  } = useData();

  const handleItemClick = (notif: typeof notifications[0]) => {
    markNotificationRead(notif.id);
    if (notif.complaintId) {
      const target = complaints.find((c) => c.id === notif.complaintId);
      if (target) {
        openComplaintDetails(target);
      }
    }
  };

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">
            Notification Center
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time updates regarding your registered campus complaints and maintenance assignments.
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            type="button"
            onClick={() => markAllNotificationsRead()}
            className="px-4 py-2 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
          >
            <CheckCheck className="w-4 h-4" />
            <span>Mark all as read</span>
          </button>
        )}
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden divide-y divide-slate-100">
        {notifications.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <Bell className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-slate-700">No notifications yet</h3>
            <p className="text-xs text-slate-400 mt-1">
              You will receive alerts here whenever your complaints are assigned, resolved, or replied to.
            </p>
          </div>
        ) : (
          notifications.map((item) => (
            <div
              key={item.id}
              onClick={() => handleItemClick(item)}
              className={`p-5 hover:bg-slate-50 transition cursor-pointer flex items-start gap-4 ${
                !item.isRead ? 'bg-blue-50/30' : ''
              }`}
            >
              <div className="mt-1">
                {item.type === 'assignment' && (
                  <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center shadow-xs">
                    <Building className="w-5 h-5" />
                  </div>
                )}
                {item.type === 'status_change' && (
                  <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shadow-xs">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                )}
                {item.type === 'message' && (
                  <div className="w-10 h-10 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center shadow-xs">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                )}
                {item.type === 'alert' && (
                  <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center shadow-xs">
                    <AlertCircle className="w-5 h-5" />
                  </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <span>{item.title}</span>
                    {!item.isRead && (
                      <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0" />
                    )}
                  </h4>
                  <span className="text-xs text-slate-400 flex items-center gap-1 shrink-0">
                    <Clock className="w-3.5 h-3.5" />
                    {new Date(item.timestamp).toLocaleString([], {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {item.message}
                </p>

                {item.complaintId && (
                  <div className="mt-2 text-xs font-mono font-bold text-blue-600 hover:underline inline-flex items-center gap-1">
                    <span>View Complaint {item.complaintId} →</span>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
