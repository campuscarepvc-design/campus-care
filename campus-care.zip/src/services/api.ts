import {
  Complaint,
  Message,
  NotificationItem,
  User,
  DashboardStats,
  MaintenanceOfficer,
} from '../types';
import {
  INITIAL_COMPLAINTS,
  INITIAL_MESSAGES,
  INITIAL_NOTIFICATIONS,
  DEMO_USERS,
  MAINTENANCE_TEAMS,
} from '../data/seedData';

// Local storage keys for resilient offline/fallback state
const STORAGE_COMPLAINTS_KEY = 'campus_care_complaints_v1';
const STORAGE_MESSAGES_KEY = 'campus_care_messages_v1';
const STORAGE_NOTIFS_KEY = 'campus_care_notifs_v1';

function getLocalComplaints(): Complaint[] {
  try {
    const raw = localStorage.getItem(STORAGE_COMPLAINTS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('LocalStorage error reading complaints', e);
  }
  return [...INITIAL_COMPLAINTS];
}

function saveLocalComplaints(data: Complaint[]) {
  try {
    localStorage.setItem(STORAGE_COMPLAINTS_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn('LocalStorage error writing complaints', e);
  }
}

function getLocalMessages(): Message[] {
  try {
    const raw = localStorage.getItem(STORAGE_MESSAGES_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('LocalStorage error reading messages', e);
  }
  return [...INITIAL_MESSAGES];
}

function saveLocalMessages(data: Message[]) {
  try {
    localStorage.setItem(STORAGE_MESSAGES_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn('LocalStorage error writing messages', e);
  }
}

function getLocalNotifications(): NotificationItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_NOTIFS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('LocalStorage error reading notifications', e);
  }
  return [...INITIAL_NOTIFICATIONS];
}

function saveLocalNotifications(data: NotificationItem[]) {
  try {
    localStorage.setItem(STORAGE_NOTIFS_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn('LocalStorage error writing notifications', e);
  }
}

export const api = {
  // Auth
  async login(id: string, password?: string, role?: string): Promise<{ success: boolean; user: User; token: string }> {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, password, role }),
      });
      if (res.ok) {
        return await res.json();
      }
      const errData = await res.json().catch(() => null);
      if (errData?.error) {
        throw new Error(errData.error);
      }
    } catch (e: any) {
      if (e?.message && e.message.includes('Access Denied')) {
        throw e;
      }
      // Continue to fallback
    }

    // Client fallback
    const trimmed = id.trim().toUpperCase();

    if (trimmed === 'STU1001' || trimmed === 'STU-2024-101') {
      if (role && role !== 'STUDENT') {
        throw new Error(`Access Denied: ID ${trimmed} is a Student account. Please select Student Login.`);
      }
      const user = DEMO_USERS['STU1001'] || DEMO_USERS['STU-2024-101'];
      return { success: true, user, token: `local_token_${user.id}` };
    }

    if (trimmed === 'FAC1001' || trimmed === 'FAC-CS-204') {
      if (role && role !== 'FACULTY') {
        throw new Error(`Access Denied: ID ${trimmed} is a Faculty account. Please select Faculty Login.`);
      }
      const user = DEMO_USERS['FAC1001'] || DEMO_USERS['FAC-CS-204'];
      return { success: true, user, token: `local_token_${user.id}` };
    }

    if (trimmed === 'HOD1001' || trimmed === 'HOD-ENG-001') {
      if (role && role !== 'HOD') {
        throw new Error(`Access Denied: ID ${trimmed} is an HOD account. Please select HOD Login.`);
      }
      const user = DEMO_USERS['HOD1001'] || DEMO_USERS['HOD-ENG-001'];
      return { success: true, user, token: `local_token_${user.id}` };
    }

    let user = Object.values(DEMO_USERS).find((u) => u.id.toUpperCase() === trimmed);
    if (user && role && user.role !== role) {
      throw new Error(`Access Denied: User ${trimmed} is registered as ${user.role}, not ${role}.`);
    }

    if (!user) {
      if (role === 'STUDENT') user = DEMO_USERS['STU1001'];
      else if (role === 'FACULTY') user = DEMO_USERS['FAC1001'];
      else user = DEMO_USERS['HOD1001'];
    }

    return {
      success: true,
      user,
      token: `local_token_${user.id}`,
    };
  },

  // Stats
  async getStats(): Promise<DashboardStats> {
    try {
      const res = await fetch('/api/stats');
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // Fallback to calculation from local storage
    }

    const complaints = getLocalComplaints();
    const totalComplaints = complaints.length;
    const pending = complaints.filter((c) => c.status === 'Pending').length;
    const assigned = complaints.filter((c) => c.status === 'Assigned').length;
    const inProgress = complaints.filter((c) => c.status === 'In Progress').length;
    const resolved = complaints.filter((c) => c.status === 'Resolved').length;
    const highPriority = complaints.filter(
      (c) => c.priority === 'High' || c.priority === 'Critical'
    ).length;
    const studentReports = complaints.filter((c) => c.submittedByRole === 'STUDENT').length;
    const facultyReports = complaints.filter((c) => c.submittedByRole === 'FACULTY').length;

    return {
      totalComplaints,
      pending,
      assigned,
      inProgress,
      resolved,
      highPriority,
      studentReports,
      facultyReports,
      averageResolutionHours: 4.8,
      resolutionRatePercentage:
        totalComplaints > 0 ? Math.round((resolved / totalComplaints) * 100) : 0,
    };
  },

  // Complaints
  async getComplaints(params?: {
    role?: string;
    submitterId?: string;
    submittedByRole?: string;
    category?: string;
    priority?: string;
    status?: string;
    search?: string;
  }): Promise<Complaint[]> {
    try {
      const query = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v) query.append(k, v);
        });
      }
      const res = await fetch(`/api/complaints?${query.toString()}`);
      if (res.ok) {
        const data = await res.json();
        saveLocalComplaints(data);
        return data;
      }
    } catch {
      // Fallback
    }

    let items = getLocalComplaints();
    if (params?.submitterId) {
      items = items.filter((c) => c.submitterId === params.submitterId);
    }
    if (params?.submittedByRole) {
      items = items.filter((c) => c.submittedByRole === params.submittedByRole);
    }
    if (params?.category && params.category !== 'ALL') {
      items = items.filter((c) => c.category === params.category);
    }
    if (params?.priority && params.priority !== 'ALL') {
      items = items.filter((c) => c.priority === params.priority);
    }
    if (params?.status && params.status !== 'ALL') {
      items = items.filter((c) => c.status === params.status);
    }
    if (params?.search) {
      const q = params.search.toLowerCase();
      items = items.filter(
        (c) =>
          c.id.toLowerCase().includes(q) ||
          c.title.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          c.location.toLowerCase().includes(q) ||
          c.classroomOrLab.toLowerCase().includes(q) ||
          c.submitterName.toLowerCase().includes(q)
      );
    }
    return items;
  },

  async createComplaint(payload: Partial<Complaint>): Promise<Complaint> {
    try {
      const res = await fetch('/api/complaints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const created = await res.json();
        const all = getLocalComplaints();
        all.unshift(created);
        saveLocalComplaints(all);
        return created;
      }
    } catch {
      // Fallback
    }

    const all = getLocalComplaints();
    let maxNum = 0;
    for (const c of all) {
      const match = c.id.match(/^CC-\d{4}-(\d+)$/);
      if (match) {
        const val = parseInt(match[1], 10);
        if (val > maxNum) maxNum = val;
      }
    }
    const newId = `CC-${new Date().getFullYear()}-${String(maxNum + 1).padStart(4, '0')}`;
    const now = new Date().toISOString();
    const room = payload.classroomOrLab && payload.classroomOrLab.trim() ? payload.classroomOrLab.trim() : 'N/A';

    const created: Complaint = {
      id: newId,
      title: payload.title || `${payload.category} Issue at ${payload.location || 'Campus'}${room !== 'N/A' ? ` (${room})` : ''}`,
      category: payload.category || 'Other',
      description: payload.description || '',
      location: payload.location || '',
      classroomOrLab: room,
      priority: payload.priority || 'Medium',
      status: 'Pending',
      photoUrl: payload.photoUrl,
      photoCaption: payload.photoCaption,
      submittedByRole: payload.submittedByRole || 'STUDENT',
      submitterId: payload.submitterId || 'STU-2024-101',
      submitterName: payload.submitterName || 'Student Submitter',
      submitterEmail: payload.submitterEmail || 'student@campuscare.edu',
      submitterDepartment: payload.submitterDepartment || 'Computer Science',
      courseOrClassAffected: payload.courseOrClassAffected,
      estimatedAffectedStudents: payload.estimatedAffectedStudents,
      createdAt: now,
      updatedAt: now,
      actionLogs: [
        {
          id: `LOG-${Date.now()}`,
          timestamp: now,
          actorName: payload.submitterName || 'User',
          actorRole: payload.submittedByRole || 'STUDENT',
          action: 'Report Submitted',
          notes: `Priority: ${payload.priority}. Location: ${payload.location}`,
        },
      ],
    };

    all.unshift(created);
    saveLocalComplaints(all);
    return created;
  },

  async assignComplaint(
    id: string,
    data: {
      assignedTo: string;
      assignedTeam: string;
      targetResolutionDate?: string;
      hodRemarks?: string;
    }
  ): Promise<Complaint> {
    try {
      const res = await fetch(`/api/complaints/${id}/assign`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        const updated = await res.json();
        const all = getLocalComplaints().map((c) => (c.id === id ? updated : c));
        saveLocalComplaints(all);
        return updated;
      }
    } catch {
      // Fallback
    }

    const all = getLocalComplaints();
    const index = all.findIndex((c) => c.id === id);
    if (index === -1) throw new Error('Complaint not found');

    const now = new Date().toISOString();
    const target = all[index];
    const updated: Complaint = {
      ...target,
      assignedTo: data.assignedTo,
      assignedTeam: data.assignedTeam,
      targetResolutionDate: data.targetResolutionDate,
      hodRemarks: data.hodRemarks,
      status: target.status === 'Pending' ? 'Assigned' : target.status,
      updatedAt: now,
      actionLogs: [
        ...target.actionLogs,
        {
          id: `LOG-${Date.now()}`,
          timestamp: now,
          actorName: 'Dr. S. Radhakrishnan',
          actorRole: 'HOD',
          action: `Assigned to ${data.assignedTeam || data.assignedTo}`,
          previousStatus: target.status,
          newStatus: target.status === 'Pending' ? 'Assigned' : target.status,
          remark: data.hodRemarks || `Assigned to ${data.assignedTeam || data.assignedTo}`,
          notes: data.hodRemarks,
          updatedBy: 'Dr. S. Radhakrishnan (HOD)',
        },
      ],
    };
    all[index] = updated;
    saveLocalComplaints(all);
    return updated;
  },

  async updateComplaintStatus(
    id: string,
    data: {
      status: string;
      remarks?: string;
      resolutionSummary?: string;
    }
  ): Promise<Complaint> {
    try {
      const res = await fetch(`/api/complaints/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        const updated = await res.json();
        const all = getLocalComplaints().map((c) => (c.id === id ? updated : c));
        saveLocalComplaints(all);
        return updated;
      }
    } catch {
      // Fallback
    }

    const all = getLocalComplaints();
    const index = all.findIndex((c) => c.id === id);
    if (index === -1) throw new Error('Complaint not found');

    const now = new Date().toISOString();
    const target = all[index];
    const updated: Complaint = {
      ...target,
      status: data.status as any,
      hodRemarks: data.remarks || target.hodRemarks,
      resolutionSummary: data.resolutionSummary || (data.status === 'Resolved' ? data.remarks : target.resolutionSummary),
      resolvedAt: data.status === 'Resolved' ? now : target.resolvedAt,
      updatedAt: now,
      actionLogs: [
        ...target.actionLogs,
        {
          id: `LOG-${Date.now()}`,
          timestamp: now,
          actorName: 'Dr. S. Radhakrishnan',
          actorRole: 'HOD',
          action: `Status changed to ${data.status}`,
          previousStatus: target.status,
          newStatus: data.status as any,
          remark: data.remarks || data.resolutionSummary || `Status changed to ${data.status}`,
          notes: data.remarks,
          updatedBy: 'Dr. S. Radhakrishnan (HOD)',
        },
      ],
    };
    all[index] = updated;
    saveLocalComplaints(all);
    return updated;
  },

  // Messages
  async getMessages(params?: { userId?: string; complaintId?: string }): Promise<Message[]> {
    try {
      const query = new URLSearchParams();
      if (params?.userId) query.append('userId', params.userId);
      if (params?.complaintId) query.append('complaintId', params.complaintId);
      const res = await fetch(`/api/messages?${query.toString()}`);
      if (res.ok) {
        const msgs = await res.json();
        saveLocalMessages(msgs);
        return msgs;
      }
    } catch {
      // Fallback
    }

    let all = getLocalMessages();
    if (params?.userId) {
      all = all.filter((m) => m.senderId === params.userId || m.recipientId === params.userId);
    }
    if (params?.complaintId) {
      all = all.filter((m) => m.complaintId === params.complaintId);
    }
    return all;
  },

  async sendMessage(payload: Partial<Message>): Promise<Message> {
    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const msg = await res.json();
        const all = getLocalMessages();
        all.push(msg);
        saveLocalMessages(all);
        return msg;
      }
    } catch {
      // Fallback
    }

    const all = getLocalMessages();
    const newMsg: Message = {
      id: `MSG-${Date.now()}`,
      senderId: payload.senderId || 'STU-2024-101',
      senderName: payload.senderName || 'Sender',
      senderRole: payload.senderRole || 'STUDENT',
      recipientId: payload.recipientId || 'HOD-ENG-001',
      recipientName: payload.recipientName || 'HOD',
      recipientRole: payload.recipientRole || 'HOD',
      complaintId: payload.complaintId,
      content: payload.content || '',
      timestamp: new Date().toISOString(),
      isRead: false,
    };
    all.push(newMsg);
    saveLocalMessages(all);
    return newMsg;
  },

  // Notifications
  async getNotifications(userId: string): Promise<NotificationItem[]> {
    try {
      const res = await fetch(`/api/notifications/${userId}`);
      if (res.ok) {
        const notifs = await res.json();
        return notifs;
      }
    } catch {
      // Fallback
    }

    return getLocalNotifications().filter((n) => n.userId === userId);
  },

  async markNotificationRead(id: string): Promise<void> {
    try {
      await fetch(`/api/notifications/${id}/read`, { method: 'PATCH' });
    } catch {
      // Fallback
    }
    const all = getLocalNotifications().map((n) => (n.id === id ? { ...n, isRead: true } : n));
    saveLocalNotifications(all);
  },

  async markAllNotificationsRead(userId: string): Promise<void> {
    try {
      await fetch(`/api/notifications/read-all/${userId}`, { method: 'PATCH' });
    } catch {
      // Fallback
    }
    const all = getLocalNotifications().map((n) => (n.userId === userId ? { ...n, isRead: true } : n));
    saveLocalNotifications(all);
  },

  // Users & Teams
  async getUsers(): Promise<User[]> {
    try {
      const res = await fetch('/api/users');
      if (res.ok) return await res.json();
    } catch {
      // Fallback
    }
    return Object.values(DEMO_USERS);
  },

  async getMaintenanceTeams(): Promise<MaintenanceOfficer[]> {
    try {
      const res = await fetch('/api/maintenance-teams');
      if (res.ok) return await res.json();
    } catch {
      // Fallback
    }
    return MAINTENANCE_TEAMS;
  },
};
