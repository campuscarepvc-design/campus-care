import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import {
  User,
  GraduationCap,
  Briefcase,
  ShieldCheck,
  Building,
  Mail,
  Phone,
  Calendar,
  Save,
  CheckCircle2,
  FileText,
} from 'lucide-react';

export const ProfileView: React.FC = () => {
  const { currentUser, role } = useAuth();
  const { complaints } = useData();

  const [phone, setPhone] = useState(currentUser?.phone || '+91 98231 44550');
  const [hostelOrCabin, setHostelOrCabin] = useState(
    currentUser?.hostelBlock || currentUser?.cabinNo || currentUser?.officeRoom || ''
  );
  const [savedSuccess, setSavedSuccess] = useState(false);

  const myComplaints = complaints.filter(
    (c) => currentUser && c.submitterId === currentUser.id
  );

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Profile Header Card */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900" />
        <div className="px-6 pb-6 pt-0 relative">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-14 mb-4">
            <div className="flex items-end gap-4">
              <img
                src={
                  currentUser?.avatar ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200'
                }
                alt={currentUser?.name}
                className="w-24 h-24 rounded-3xl object-cover border-4 border-white shadow-md bg-white"
              />
              <div className="pb-1">
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                    {currentUser?.name}
                  </h1>
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 font-mono">
                    {role}
                  </span>
                </div>
                <p className="text-xs text-blue-700 font-mono font-bold mt-0.5">
                  ID: {currentUser?.id}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Active Campus Account
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-100 text-xs">
            <div>
              <span className="text-slate-400 block font-semibold uppercase text-[10px]">
                Department
              </span>
              <span className="text-slate-800 font-bold mt-0.5 block">
                {currentUser?.department}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block font-semibold uppercase text-[10px]">
                Email Address
              </span>
              <span className="text-slate-800 font-bold mt-0.5 block">
                {currentUser?.email}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block font-semibold uppercase text-[10px]">
                Campus Role Designation
              </span>
              <span className="text-slate-800 font-bold mt-0.5 block">
                {currentUser?.designation || (role === 'STUDENT' ? 'B.Tech Scholar' : 'Administrator')}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Editable Contact & Location Info */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6">
        <h3 className="text-base font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Building className="w-4 h-4 text-blue-600" />
          <span>Campus Residence & Communication Details</span>
        </h3>

        {savedSuccess && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Profile settings updated successfully!</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Contact Phone Number
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3.5 py-2.5 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                {role === 'STUDENT' ? 'Hostel & Room No.' : 'Faculty Cabin / Office Room'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={hostelOrCabin}
                  onChange={(e) => setHostelOrCabin(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3.5 py-2.5 text-xs text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
                <Building className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              </div>
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/30 flex items-center gap-2 cursor-pointer transition"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Changes</span>
            </button>
          </div>
        </form>
      </div>

      {/* Activity Log / Submissions */}
      {role !== 'HOD' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs p-6">
          <h3 className="text-base font-bold text-slate-900 mb-3 flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-600" />
            <span>My Registered Tickets ({myComplaints.length})</span>
          </h3>

          <div className="divide-y divide-slate-100">
            {myComplaints.map((item) => (
              <div key={item.id} className="py-3 flex items-center justify-between text-xs">
                <div>
                  <span className="font-mono font-bold text-blue-700 mr-2">{item.id}</span>
                  <span className="font-semibold text-slate-800">{item.title}</span>
                </div>
                <div className="text-slate-400">
                  {new Date(item.createdAt).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
