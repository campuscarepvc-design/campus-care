import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { DEMO_USERS } from '../data/seedData';
import { api } from '../services/api';

interface AuthContextType {
  currentUser: User | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  login: (id: string, password?: string, preferredRole?: UserRole) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  switchRoleQuick: (role: UserRole) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_AUTH_USER_KEY = 'campus_care_auth_user_v1';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_AUTH_USER_KEY);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.error(e);
    }
    // Starts as null so user arrives at the Role Selection & Login screen
    return null;
  });

  const role = currentUser ? currentUser.role : null;
  const isAuthenticated = !!currentUser;

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_AUTH_USER_KEY, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_AUTH_USER_KEY);
    }
  }, [currentUser]);

  const login = async (
    id: string,
    password?: string,
    preferredRole?: UserRole
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await api.login(id, password, preferredRole);
      if (res.success && res.user) {
        setCurrentUser(res.user);
        return { success: true };
      }
      return { success: false, error: 'Invalid identification credentials.' };
    } catch (e: any) {
      console.error('Login error', e);
      return { success: false, error: e?.message || 'Authentication failed. Please verify your credentials.' };
    }
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const switchRoleQuick = (targetRole: UserRole) => {
    if (targetRole === 'STUDENT') {
      setCurrentUser(DEMO_USERS['STU1001']);
    } else if (targetRole === 'FACULTY') {
      setCurrentUser(DEMO_USERS['FAC1001']);
    } else if (targetRole === 'HOD') {
      setCurrentUser(DEMO_USERS['HOD1001']);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        role,
        isAuthenticated,
        login,
        logout,
        switchRoleQuick,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
