import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { User, Message, Complaint } from '../../types';
import {
  Send,
  MessageSquare,
  Sparkles,
  Building,
  GraduationCap,
  Briefcase,
  ShieldCheck,
  Check,
  CheckCheck,
  Clock,
} from 'lucide-react';

interface InternalMessagingViewProps {
  initialComplaintContext?: Complaint | null;
}

export const InternalMessagingView: React.FC<InternalMessagingViewProps> = ({
  initialComplaintContext,
}) => {
  const { currentUser, role } = useAuth();
  const { messages, sendMessage, allUsers, complaints } = useData();

  // For HOD, we allow selecting between Students & Faculty
  const [selectedRecipientId, setSelectedRecipientId] = useState<string>(() => {
    if (initialComplaintContext) {
      return initialComplaintContext.submitterId;
    }
    if (role === 'HOD') {
      return 'STU1001';
    }
    return 'HOD1001';
  });

  const [messageText, setMessageText] = useState('');
  const [selectedComplaintId, setSelectedComplaintId] = useState<string | undefined>(
    initialComplaintContext?.id
  );
  const [isSending, setIsSending] = useState(false);

  // Sync when initialComplaintContext prop changes
  React.useEffect(() => {
    if (initialComplaintContext) {
      setSelectedRecipientId(initialComplaintContext.submitterId);
      setSelectedComplaintId(initialComplaintContext.id);
    }
  }, [initialComplaintContext]);

  // List of potential chat partners for HOD
  const students = allUsers.filter((u) => u.role === 'STUDENT');
  const faculties = allUsers.filter((u) => u.role === 'FACULTY');
  const hodUser = allUsers.find((u) => u.role === 'HOD') || {
    id: 'HOD-ENG-001',
    name: 'Dr. S. Radhakrishnan',
    role: 'HOD',
    department: 'Campus Operations & Engineering',
  };

  // Determine active thread messages
  const activeRecipient =
    allUsers.find((u) => u.id === selectedRecipientId) ||
    (role === 'HOD' ? students[0] : (hodUser as User));

  const threadMessages = messages.filter((m) => {
    if (!currentUser || !activeRecipient) return false;
    const isCurrentUserSender = m.senderId === currentUser.id && m.recipientId === activeRecipient.id;
    const isCurrentUserRecipient = m.senderId === activeRecipient.id && m.recipientId === currentUser.id;
    return isCurrentUserSender || isCurrentUserRecipient;
  });

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !currentUser || !activeRecipient) return;

    setIsSending(true);
    try {
      await sendMessage({
        senderId: currentUser.id,
        senderName: currentUser.name,
        senderRole: currentUser.role,
        recipientId: activeRecipient.id,
        recipientName: activeRecipient.name,
        recipientRole: activeRecipient.role,
        complaintId: selectedComplaintId,
        content: messageText.trim(),
      });
      setMessageText('');
    } catch (err) {
      console.error(err);
    } finally {
      setIsSending(false);
    }
  };

  const quickTemplates =
    role === 'HOD'
      ? [
          'Technician has been dispatched to inspect your reported room.',
          'Please confirm if the issue is now functioning properly.',
          'Due to parts order delay, ETA is pushed to tomorrow morning.',
        ]
      : [
          'Could we get an approximate ETA for technician arrival?',
          'Class has been temporarily shifted to adjacent lecture hall.',
          'Thank you Sir, the maintenance team successfully resolved it!',
        ];

  const recipientComplaints = complaints.filter(
    (c) =>
      c.submitterId === activeRecipient?.id ||
      (activeRecipient?.id === 'STU1001' && c.submitterId === 'STU-2024-101') ||
      (activeRecipient?.id === 'FAC1001' && c.submitterId === 'FAC-CS-204')
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight">
          Internal Campus Communications
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          {role === 'HOD'
            ? 'Official communication bridge with students and faculty regarding infrastructure reports.'
            : 'Direct, transparent communication channel with Dr. S. Radhakrishnan (HOD Operations).'}
        </p>
      </div>

      {/* Main Messaging Layout */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col md:flex-row min-h-[580px]">
        {/* Left Side: Conversation Partner Selector (especially useful for HOD) */}
        <div className="w-full md:w-80 border-r border-slate-200 bg-slate-50/70 p-4 shrink-0 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Active Conversations
            </div>

            {role !== 'HOD' ? (
              // Student / Faculty view: HOD Profile card
              <div className="p-4 rounded-2xl bg-white border border-blue-200 shadow-xs">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-blue-700 text-white flex items-center justify-center font-bold shadow-md shadow-blue-700/20">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">
                      {hodUser.name}
                    </div>
                    <div className="text-xs text-blue-700 font-semibold">
                      HOD Operations
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Admin Tower, Room 102
                    </div>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-2 text-[11px] text-emerald-700 font-semibold">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Online • Avg reply &lt; 15 mins</span>
                </div>
              </div>
            ) : (
              // HOD view: Tabbed list of Students & Faculty
              <div className="space-y-3">
                <div>
                  <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <GraduationCap className="w-3.5 h-3.5 text-blue-600" />
                    <span>Students</span>
                  </div>
                  <div className="space-y-1.5">
                    {students.map((student) => {
                      const isSelected = selectedRecipientId === student.id;
                      return (
                        <button
                          key={student.id}
                          type="button"
                          onClick={() => setSelectedRecipientId(student.id)}
                          className={`w-full p-2.5 rounded-xl border text-left flex items-center gap-3 transition cursor-pointer ${
                            isSelected
                              ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                              : 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700'
                          }`}
                        >
                          <div
                            className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                              isSelected
                                ? 'bg-white/20 text-white'
                                : 'bg-blue-100 text-blue-700'
                            }`}
                          >
                            {student.name.charAt(0)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-bold truncate">
                              {student.name}
                            </div>
                            <div
                              className={`text-[10px] truncate ${
                                isSelected ? 'text-blue-100' : 'text-slate-400'
                              }`}
                            >
                              {student.id} • {student.department}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-2">
                  <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Briefcase className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Faculty Members</span>
                  </div>
                  <div className="space-y-1.5">
                    {faculties.map((fac) => {
                      const isSelected = selectedRecipientId === fac.id;
                      return (
                        <button
                          key={fac.id}
                          type="button"
                          onClick={() => setSelectedRecipientId(fac.id)}
                          className={`w-full p-2.5 rounded-xl border text-left flex items-center gap-3 transition cursor-pointer ${
                            isSelected
                              ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                              : 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700'
                          }`}
                        >
                          <div
                            className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                              isSelected
                                ? 'bg-white/20 text-white'
                                : 'bg-indigo-100 text-indigo-700'
                            }`}
                          >
                            {fac.name.charAt(0)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-bold truncate">
                              {fac.name}
                            </div>
                            <div
                              className={`text-[10px] truncate ${
                                isSelected ? 'text-blue-100' : 'text-slate-400'
                              }`}
                            >
                              {fac.id} • {fac.department}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="mt-4 p-3 rounded-xl bg-slate-100/80 border border-slate-200 text-[11px] text-slate-500">
            Messages are recorded in campus administrative records for transparency.
          </div>
        </div>

        {/* Right Side: Message Thread View */}
        <div className="flex-1 flex flex-col justify-between bg-white">
          {/* Active Conversation Header */}
          <div className="p-4 border-b border-slate-200 bg-slate-50/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold text-sm">
                {activeRecipient?.name?.charAt(0) || 'U'}
              </div>
              <div>
                <div className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <span>{activeRecipient?.name}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 font-mono">
                    {activeRecipient?.role}
                  </span>
                </div>
                <div className="text-xs text-slate-500 font-mono">
                  {activeRecipient?.id} • {activeRecipient?.department}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {role === 'HOD' && recipientComplaints.length > 0 && (
                <div className="flex items-center gap-1.5">
                  <label htmlFor="complaintRefSelect" className="text-[10px] font-bold text-slate-400 uppercase tracking-wider hidden sm:inline">
                    Ref Ticket:
                  </label>
                  <select
                    id="complaintRefSelect"
                    value={selectedComplaintId || ''}
                    onChange={(e) => setSelectedComplaintId(e.target.value || undefined)}
                    className="text-xs bg-slate-50 border border-slate-300 rounded-lg px-2 py-1 font-mono text-blue-700 font-bold focus:outline-none focus:ring-1 focus:ring-blue-600"
                  >
                    <option value="">No Ticket Ref</option>
                    {recipientComplaints.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.id} - {c.category} ({c.status})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {selectedComplaintId && (!role || role !== 'HOD' || recipientComplaints.length === 0) && (
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">Complaint Reference</span>
                  <span className="font-mono text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200">
                    {selectedComplaintId}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Messages Scroll Area */}
          <div className="p-6 overflow-y-auto space-y-4 max-h-[420px] flex-1">
            {threadMessages.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-400">
                <MessageSquare className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="font-semibold text-slate-600">No messages in this thread yet</p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Send a message to start direct communication.
                </p>
              </div>
            ) : (
              threadMessages.map((msg) => {
                const isMe = currentUser && msg.senderId === currentUser.id;
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 mb-1 px-1">
                      <span className="font-bold text-slate-600">{msg.senderName}</span>
                      <span>•</span>
                      <span>
                        {new Date(msg.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>

                    <div
                      className={`max-w-md p-3.5 rounded-2xl text-xs leading-relaxed shadow-xs ${
                        isMe
                          ? 'bg-blue-600 text-white rounded-br-xs'
                          : 'bg-slate-100 text-slate-800 rounded-bl-xs border border-slate-200'
                      }`}
                    >
                      {msg.complaintId && (
                        <div
                          className={`mb-1.5 pb-1.5 border-b text-[10px] font-mono font-bold flex items-center justify-between ${
                            isMe ? 'border-blue-400/40 text-blue-100' : 'border-slate-200 text-blue-700'
                          }`}
                        >
                          <span>Re: {msg.complaintId}</span>
                        </div>
                      )}
                      <div>{msg.content}</div>
                    </div>

                    <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-1 px-1">
                      {isMe && (
                        <span>
                          {msg.isRead ? (
                            <CheckCheck className="w-3.5 h-3.5 text-blue-600 inline" />
                          ) : (
                            <Check className="w-3.5 h-3.5 text-slate-400 inline" />
                          )}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Quick Response Templates */}
          <div className="px-6 py-2 bg-slate-50 border-t border-slate-100 flex items-center gap-2 overflow-x-auto">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 whitespace-nowrap flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-blue-600" /> Presets:
            </span>
            {quickTemplates.map((tpl, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setMessageText(tpl)}
                className="px-2.5 py-1 rounded-full bg-white hover:bg-blue-50 border border-slate-200 text-[11px] text-slate-600 hover:text-blue-700 whitespace-nowrap transition cursor-pointer shadow-2xs"
              >
                {tpl}
              </button>
            ))}
          </div>

          {/* Input Bar */}
          <form onSubmit={handleSend} className="p-4 border-t border-slate-200 bg-white flex items-center gap-3">
            <div className="flex-1 relative">
              <input
                type="text"
                required
                placeholder={`Type a message to ${activeRecipient?.name}...`}
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-2xl px-4 py-3 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>
            <button
              type="submit"
              disabled={isSending || !messageText.trim()}
              className="p-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white transition shadow-md shadow-blue-600/30 cursor-pointer disabled:opacity-50 shrink-0"
              title="Send Message"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
